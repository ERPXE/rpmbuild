ln -s /tftpboot/er/shares /var/www/html/er
